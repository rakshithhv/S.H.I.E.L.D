package cloud.artik.example.hellocloud;

class Config {
    static final String CLIENT_ID = "67e9ada230244c4db5e075af1eba4b17"; // AKA application ID
    static final String DEVICE_ID = "4e32844d26894739aa5ac9ca54fe3b45";

    // MUST be consistent with "AUTH REDIRECT URL" of your application set up at the developer.artik.cloud
    static final String REDIRECT_URI = "cloud.artik.example.hellocloud://oauth2callback";

}
